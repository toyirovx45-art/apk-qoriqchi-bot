import os
import time
import hmac
import hashlib
import base64
import threading
from urllib.parse import quote

import telebot
from telebot.types import ChatPermissions
from flask import Flask, abort, redirect, Response

BOT_TOKEN = os.environ["BOT_TOKEN"]
PUBLIC_URL = os.environ["PUBLIC_URL"].rstrip("/")
APK_URL = os.environ["APK_URL"]
SIGNING_SECRET = os.environ["SIGNING_SECRET"].encode("utf-8")

bot = telebot.TeleBot(BOT_TOKEN)
app = Flask(__name__)

def make_token(chat_id: int, user_id: int) -> str:
    # Link is valid for 24 hours and is tied to one Telegram user in one group.
    payload = f"{chat_id}:{user_id}:{int(time.time()) + 86400}".encode()
    sig = hmac.new(SIGNING_SECRET, payload, hashlib.sha256).digest()
    return base64.urlsafe_b64encode(payload + b"." + sig).decode().rstrip("=")

def read_token(token: str):
    try:
        raw = base64.urlsafe_b64decode(token + "=" * (-len(token) % 4))
        payload, sig = raw.rsplit(b".", 1)
        expected = hmac.new(SIGNING_SECRET, payload, hashlib.sha256).digest()
        if not hmac.compare_digest(sig, expected):
            return None
        chat_id_s, user_id_s, expires_s = payload.decode().split(":")
        if int(expires_s) < int(time.time()):
            return None
        return int(chat_id_s), int(user_id_s)
    except Exception:
        return None

def allow_user(chat_id: int, user_id: int):
    # Restores common group messaging permissions. Group-wide default restrictions
    # may still apply.
    permissions = ChatPermissions(
        can_send_messages=True,
        can_send_audios=True,
        can_send_documents=True,
        can_send_photos=True,
        can_send_videos=True,
        can_send_video_notes=True,
        can_send_voice_notes=True,
        can_send_polls=True,
        can_send_other_messages=True,
        can_add_web_page_previews=True,
    )
    bot.restrict_chat_member(
        chat_id=chat_id,
        user_id=user_id,
        permissions=permissions,
        use_independent_chat_permissions=True,
    )

def restrict_user(chat_id: int, user_id: int):
    permissions = ChatPermissions(
        can_send_messages=False,
        can_send_audios=False,
        can_send_documents=False,
        can_send_photos=False,
        can_send_videos=False,
        can_send_video_notes=False,
        can_send_voice_notes=False,
        can_send_polls=False,
        can_send_other_messages=False,
        can_add_web_page_previews=False,
    )
    bot.restrict_chat_member(
        chat_id=chat_id,
        user_id=user_id,
        permissions=permissions,
        use_independent_chat_permissions=True,
    )

@bot.message_handler(content_types=["new_chat_members"])
def on_new_members(message):
    for member in message.new_chat_members:
        if member.is_bot:
            continue
        try:
            restrict_user(message.chat.id, member.id)
            token = make_token(message.chat.id, member.id)
            tracked_url = f"{PUBLIC_URL}/go/{quote(token)}"
            bot.send_message(
                message.chat.id,
                f"Salom, {member.first_name}!\n"
                "Guruhda yozish uchun quyidagi havolani bosing:\n"
                f"{tracked_url}\n\n"
                "Havola ochilgach, yozish huquqingiz avtomatik ochiladi."
            )
        except Exception as exc:
            print(f"New member processing failed: {exc}")

@app.get("/")
def home():
    return Response("Telegram membership bot is running.", mimetype="text/plain")

@app.get("/go/<token>")
def tracked_click(token):
    details = read_token(token)
    if not details:
        return Response(
            "Havola yaroqsiz yoki muddati tugagan. Guruhdagi botdan yangi havola oling.",
            status=400,
            mimetype="text/plain",
        )

    chat_id, user_id = details
    try:
        allow_user(chat_id, user_id)
        # Redirect the browser to the user's original APK campaign link.
        return redirect(APK_URL, code=302)
    except Exception as exc:
        print(f"Could not unlock member {user_id}: {exc}")
        return Response(
            "Ruxsatni ochib bo'lmadi. Bot guruhda administrator ekanini tekshiring.",
            status=503,
            mimetype="text/plain",
        )

def run_flask():
    port = int(os.environ.get("PORT", "10000"))
    app.run(host="0.0.0.0", port=port)

if __name__ == "__main__":
    threading.Thread(target=run_flask, daemon=True).start()
    print("Bot polling started")
    bot.infinity_polling(skip_pending=True, timeout=30, long_polling_timeout=30)
