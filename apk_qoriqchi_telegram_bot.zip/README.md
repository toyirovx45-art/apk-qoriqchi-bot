# APK Qo'riqchi Telegram guruh boti

## Muhim
Bu bot APK o'rnatilganini tekshirmaydi. U faqat maxsus kuzatuv havolasi ochilganini qayd etadi. Havola ochilishi bilan bot tegishli Telegram foydalanuvchisining guruhdagi yozish huquqini ochadi va brauzerni APK Qo'riqchi havolasiga yo'naltiradi.

## GitHub'ga yuklash
1. GitHub'da yangi public yoki private repository yarating.
2. Ushbu ZIP ichidagi `main.py`, `requirements.txt`, `render.yaml` fayllarini repository root'iga yuklang.

## Render sozlamalari
Render'da New > Web Service orqali repository'ni ulang. Build command: `pip install -r requirements.txt`. Start command: `python main.py`.
Environment variables:
- `BOT_TOKEN`: BotFather bergan token (hech kimga bermang).
- `PUBLIC_URL`: Render bergan `https://....onrender.com` manzili.
- `APK_URL`: oldindan kiritilgan APK havolasi.
- `SIGNING_SECRET`: kamida 32 belgidan iborat tasodifiy maxfiy kalit.

## Telegram sozlamalari
Bot guruhda administrator bo'lishi va `Restrict members / A'zolarni cheklash` huquqiga ega bo'lishi kerak.
Botni guruhga qo'shgandan keyin yangi a'zolar kirib sinab ko'ring.

## Cheklovlar
- Telegram bot API guruhga kirgan yangi a'zoni cheklashni qo'llab-quvvatlaydi.
- Maxsus havolani kim bosganini bu loyiha o'rnatilgan ilova bilan tekshirmaydi; faqat tracking link bosilganini biladi.
- Havola foydalanuvchiga bog'langan. Uni boshqa odam bosgan taqdirda ham faqat havola yaratilgan Telegram foydalanuvchisining yozish huquqi ochiladi.
- Render bepul xizmatlari uxlab qolishi yoki vaqtincha to'xtashi mumkin; bunday paytda bot darhol javob bermasligi mumkin.
- Guruhning administrator huquqlari va Telegram Bot API cheklovlari sababli amalda sinovdan o'tkazish zarur.
